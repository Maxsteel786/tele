import React from "react";
import Appointments from "@/components/patientProfile/upcoming_appointments/Appointments";
const AppointmentsPage = () => {
  return <Appointments />;
};

export default AppointmentsPage;
