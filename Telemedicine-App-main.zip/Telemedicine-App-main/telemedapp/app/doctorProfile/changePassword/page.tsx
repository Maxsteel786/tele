import ChangePassword from "@/components/doctorProfile/ChangePassword";

function ChangePasswordPage() {
  return <ChangePassword />;
}

export default ChangePasswordPage;
