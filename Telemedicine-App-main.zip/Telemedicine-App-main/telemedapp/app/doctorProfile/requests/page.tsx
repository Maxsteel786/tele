import Requests from "@/components/doctorProfile/requests";

function RequestsPage() {
  return <Requests />;
}

export default RequestsPage;
