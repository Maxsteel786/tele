import SignInForm from "@/components/auth/SignInForm";

function SignInPage() {
  return <SignInForm />;
}

export default SignInPage;
